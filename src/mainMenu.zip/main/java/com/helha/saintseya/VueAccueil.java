package com.helha.saintseya;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;

public class VueAccueil {
    private Scene scene;

    public VueAccueil(SaintSeiyaApp app) {
        VBox root = new VBox(30);
        root.setAlignment(Pos.CENTER);
        root.setStyle(StyleConstantes.FOND);

        Label titre = new Label("SAINT SEIYA : THE 12 HOUSES OF KNOWLEDGE");
        titre.setStyle(StyleConstantes.TITRE);


        titre.setWrapText(true);
        titre.setTextAlignment(TextAlignment.CENTER);
        titre.setMaxWidth(1800);

        Button btnJouer = new Button("PLAY");
        btnJouer.setStyle(StyleConstantes.BOUTON);
        btnJouer.setPrefWidth(200);
        btnJouer.setOnAction(e -> app.changerVersSelection());

        Button btnOptions = new Button("OPTIONS");
        btnOptions.setStyle(StyleConstantes.BOUTON);
        btnOptions.setPrefWidth(200);
        btnOptions.setOnAction(e -> System.out.println(" Options Soon..."));

        Button btnQuitter = new Button("QUIT");
        btnQuitter.setStyle(StyleConstantes.BOUTON);
        btnQuitter.setPrefWidth(200);
        btnQuitter.setOnAction(e -> Platform.exit());

        root.getChildren().addAll(titre, btnJouer, btnOptions, btnQuitter);


        scene = new Scene(root, 1920, 1080);
    }

    public Scene getScene() {
        return scene;
    }
}