package com.helha.saintseya;

import javafx.application.Application;
import javafx.stage.Stage;

public class SaintSeiyaApp extends Application {

    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Saint Seiya - The Game");


        changerVersAccueil();

        this.primaryStage.setWidth(800);
        this.primaryStage.setHeight(600);
        this.primaryStage.show();
    }

    public void changerVersAccueil() {
        VueAccueil vue = new VueAccueil(this);
        primaryStage.setScene(vue.getScene());
    }


    public void changerVersSelection() {
        VueSelection vue = new VueSelection(this);
        primaryStage.setScene(vue.getScene());
    }
}
