package com.helha.saintseya;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ContentDisplay;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class VueSelection {
    private Scene scene;

    public VueSelection(SaintSeiyaApp app) {
        VBox root = new VBox(40);
        root.setAlignment(Pos.CENTER);
        root.setStyle(StyleConstantes.FOND);

        Label titre = new Label("CHOISISSEZ VOTRE CHEVALIER");
        titre.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 28px; -fx-font-weight: bold;");

        HBox conteneurPions = new HBox(20);
        conteneurPions.setAlignment(Pos.CENTER);

        // Tableau contenant le nom à afficher ET le nom du fichier image
        String[][] chevaliers = {
                {"Pégase", "seiya.png"},
                {"Dragon", "shiryu.png"},
                {"Cygne", "hyoga.png"},
                {"Andromède", "shun.png"}
        };

        for (String[] donnees : chevaliers) {
            String nom = donnees[0];
            String fichierImage = donnees[1];

            Button pion = new Button(nom);
            pion.setStyle(StyleConstantes.PION);
            // Placer le texte sous l'image
            pion.setContentDisplay(ContentDisplay.TOP);

            // Chargement de l'image
            try {

                Image img = new Image(getClass().getResourceAsStream("/com/helha/saintseya/" + fichierImage));
                ImageView vueImage = new ImageView(img);
                vueImage.setFitHeight(100);
                vueImage.setPreserveRatio(true);

                // On ajoute l'image au bouton
                pion.setGraphic(vueImage);
            } catch (Exception ex) {
                System.out.println("⚠️ Image introuvable : /images/" + fichierImage);
            }


            pion.setOnMouseEntered(e -> pion.setStyle(StyleConstantes.PION + "-fx-background-color: #FFD700;"));
            pion.setOnMouseExited(e -> pion.setStyle(StyleConstantes.PION));


            pion.setOnAction(e -> {
                System.out.println("Vous avez sélectionné le Chevalier : " + nom);
                // C'est ici qu'on appellera la vue du plateau de jeu plus tard !
            });

            conteneurPions.getChildren().add(pion);
        }

        Button btnRetour = new Button("RETOUR");
        btnRetour.setStyle(StyleConstantes.BOUTON);
        btnRetour.setOnAction(e -> app.changerVersAccueil());

        root.getChildren().addAll(titre, conteneurPions, btnRetour);
        scene = new Scene(root);
    }

    public Scene getScene() {
        return scene;
    }
}